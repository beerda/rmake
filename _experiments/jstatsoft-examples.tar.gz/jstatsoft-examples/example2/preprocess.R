d <- read.csv("data.csv")
saveRDS(d, "data.rds")
